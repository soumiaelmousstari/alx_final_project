var valider=document.querySelector(".valider")
var input=document.querySelector("input");
//console.log(valider);
//document.cookie="v="+input.value;
valider.addEventListener("click",function(){
    document.cookie="v="+input.value;
})