<?php
    require("connexion.php");
    require("Utilisateur.php");
    session_start();
    if(!isset($_SESSION["permission"])){
        header("location:index.php");
    }
?>
<html>
    <head>
        <link rel="stylesheet" href="Nouveau.css">
        <link rel="stylesheet" href="Nouveau_user.css">
    </head>
    <body>
        <form class="add" method="post">
                <?php
                    $in_Code="";
                    $in_Login="";
                    $in_MotPasse="";
                    $in_Email="";
                    $in_Categorie="";
                    if(isset($_GET["user_to_modify"])){
                        $i=new Utilisateur($_GET["user_to_modify"]);
                        $r=$i->SelectFromBD();
                        $in_Code=$r["Code"];
                        $in_Login=$r["Login"];
                        $in_MotPasse=$r["MotPasse"];
                        $in_Email=$r["Email"];
                        $in_Categorie=$r["Categorie"];
                    }
                    /*if(isset($_GET["user_to_modify"])){
                        echo"
                            Code
                            <input type='text' name='code' value='$in_Code' required>
                        ";
                    }*/
                    echo"
                        Login
                        <input type='text' name='login' value='$in_Login' required>
                    
                        MotPasse
                        <input type='text' name='motpasse' value='$in_MotPasse' required>

                        Email
                        <input type='email' name='email' value='$in_Email' required>

                        
                        ";
                    if($in_Categorie=='Administrateur'){
                        echo"
                        Categorie
                        <select name='categorie'required>
                            <option selected value='Administrateur'>Administrateur</option>
                            <option value='Professeur'>Professeur</option>
                            <option value='Etudiant'>Etudiant</option>
                        </select>
                        ";
                    }
                    elseif($in_Categorie=='Professeur'){
                        echo"
                        Categorie
                        <select name='categorie'required>
                            <option value='Administrateur'>Administrateur</option>
                            <option selected value='Professeur'>Professeur</option>
                            <option value='Etudiant'>Etudiant</option>
                        </select>
                        ";
                    }
                    elseif($in_Categorie=='Etudiant'){
                        echo"
                        Categorie
                        <select name='categorie'required>
                            <option value='Administrateur'>Administrateur</option>
                            <option value='Professeur'>Professeur</option>
                            <option selected value='Etudiant'>Etudiant</option>
                        </select>
                        ";
                    }
                    else{
                        echo"
                        Categorie
                        <select name='categorie'required>
                            <option value='Administrateur'>Administrateur</option>
                            <option value='Professeur'>Professeur</option>
                            <option value='Etudiant'>Etudiant</option>
                        </select>
                        ";
                    }
                    if(isset($_POST["login"]) and isset($_POST["motpasse"]) and isset($_POST["categorie"]) and isset($_POST["email"])){
                        if(isset($_GET["user_to_modify"])){
                            $i=new Utilisateur($_GET["user_to_modify"],$_POST["login"],$_POST["motpasse"],$_POST["email"],$_POST["categorie"]);
                            $i->UpdateInBD();
                            header("location:creation.php");
                        }
                        else{
                            $i=new Utilisateur(0,$_POST["login"],$_POST["motpasse"],$_POST["email"],$_POST["categorie"]);
                            $i->AddToBD();
                            header("location:creation.php");
                        }
                        
                    }
                ?>
                <div class="button-container">
                    <input class="button" type="submit" value="Valider">
                    <a class="href" href="creation.php"><input class="button" type="button" value="Annuler"></a>
                </div>
                
        </form>
        <?php
            /*if(isset($_POST['Valider']) && $_SERVER["REQUEST_METHOD"]=="POST"){
                echo"test";
                //$i=new Utilisateur(0,$_POST["login"],$_POST["motpasse"],$_POST["email"],$_POST["categorie"]);
                //$i->AddToBD();
                //header("locaton:creation.php");
            }*/
        ?>
    </body>
</html>