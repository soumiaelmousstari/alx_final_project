<?php
    require("Etudiant.php");
    require("connexion.php");
    require("Utilisateur.php");
    session_start();
    if(!isset($_SESSION["permission"])){
        header("location:index.php");
    }
    $e=new Etudiant($_GET["bulletin_id"]);
    $r=$e->SelectFromBD();
    $moyenne=($r["math"]+$r["info"])/2;
    if($moyenne>=10 and $moyenne<12){
        $mention="Passable";
    }
    elseif($moyenne>=12 and $moyenne<14){
        $mention="A Bien";
    }
    elseif($moyenne>=14 and $moyenne<16){
        $mention="Bien";
    }
    elseif($moyenne>=16 and $moyenne<=20){
        $mention="Tres Bien";
    }
    else{
        $mention="Non Admit";
    }
?>
<?php
require("Fpdf/fpdf.php");
// Define the PDF document properties
$pdf = new FPDF();
// Add a new page
$pdf->AddPage();
// Set the font
$pdf->SetFont('times', 'BI', 12);

// Add some content
$pdf->Cell(0, 10, 'Student Grade', 0, 1);
$pdf->Cell(0, 10, 'Name: ' .$r["nom"], 0, 1);
$pdf->Cell(0, 10, 'Math Grade: ' .$r["math"], 0, 1);
$pdf->Cell(0, 10, 'Info Grade: ' .$r["info"], 0, 1);
$pdf->Cell(0, 10, 'Moyen: ' . $moyenne , 0, 1);
$pdf->Cell(0, 10, 'Mention: '.$mention, 0, 1);

// Output the PDF file
$pdf->Output("natija.pdf",'I');
?>