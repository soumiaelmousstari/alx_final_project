<?php
    require("connexion.php");
    require("Utilisateur.php");
    session_start();
    if(!isset($_SESSION["permission"])){
        header("location:index.php");
    }
    try{
        $connection=connextion::single()->getconnextion();
    }
    catch(PDOException $e){
        echo"erreur lors de connection a la base<br>".$e->getMessage();
    }
?>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="Affichage_css.php">
        <link rel="stylesheet" href="creation.css">
    </head>
    <body>
        <div class="creation">
            <a href="compte.php"><button>COMPTE</button></a>
        </div>
        <form class="form" action="Nouveau_user.php" method="post">
            <div class="input-crud">
                <input type="submit" name="Nouveau" value="Nouveau">
                <a href="Affichage.php"><input id="quitter" type="button" value="Quitter"></a>
            </div>
            <ul class="menu menu-item__specify">
                <li class="menu-item">Code</li>
                <li class="menu-item">Login</li>
                <li class="menu-item">MotPasse</li>
                <li class="menu-item">Email</li>
                <li class="menu-item">Categorie</li>
            </ul>
            <?php
                ob_start();
                $results=$connection->query("select * from utilisateur");
                while($result=$results->fetch()){
                    if($result["Code"]!=$_SESSION["user_id"] and $result["valide"]==1){
                        echo"
                        <div class='menu-container'>
                            <ul class='menu'>
                                <li class='menu-item'>".$result['Code']."</li>
                                <li class='menu-item'>".$result['Login']."</li>
                                <li class='menu-item'>".$result['MotPasse']."</li>
                                <li class='menu-item'>".$result['Email']."</li>
                                <li class='menu-item'>".$result['Categorie']."</li>
                            </ul>
                            <div class='button'>
                                <a href='Nouveau_user.php?user_to_modify=".$result['Code']."'><input type='button' value='M'></a>
                                <a href='creation.php?user_to_delete=".$result['Code']."'><input type='button' value='S'></a>
                            </div>
                        </div>
                        ";
                    }
                }
                if(isset($_GET["user_to_delete"])){
                    $i=new Utilisateur($_GET["user_to_delete"]);
                    $i->DeleteFromBD();
                    header("location:creation.php");
                }
                ob_end_flush();
            ?>
        </form>
    </body>
</html>