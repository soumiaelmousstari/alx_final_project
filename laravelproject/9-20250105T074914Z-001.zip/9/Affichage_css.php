<?php
    session_start();
    header("content-type: text/css");
?>
*{
    box-sizing: border-box;
}

body{
    margin:0;
    background: linear-gradient(burlywood,transparent);
    font-family: monospace;
    font-size: large;
    position: relative;
}

.creation button{
    position: absolute;
    left: 5%;
    top: 2%;
    border-radius: 10px;
    font: inherit;
    cursor: pointer;
    border: none;
    background: black;
    color: white;
    padding: 0.5rem 1.5rem;
}

.creation .hi{
    position: absolute;
    left: 23%;
    <?php if($_SESSION["permission"]=='Professeur'){echo"left: 5%;";}?>
    top: 2%;
    border-radius: 10px;
    font: inherit;
    cursor: pointer;
    border: none;
    background: black;
    padding: 0.5rem 1.5rem;
}

.hi{
    color: white;
    text-decoration:none;
}

.creation .hi:hover{
    color: black;
    background:white;
}

.creation button:hover{
    color: black;
    background:white;
}

.form{
    width: 80%;
    padding: 5rem 3rem;
    margin: 0 auto;
}

.input-crud{
    padding-bottom:1rem ;
    <?php
        /*if($_SESSION["permission"]=='e'){
            echo"display: none;";
        }*/
    ?>
}

.input-crud input{
    box-shadow: 0px 0px 0px 1px white;
    border-radius: 10px;
    font: inherit;
    cursor: pointer;
    border: none;
    background: center;
    width: 8rem;
    padding: 5px 8px;
}

.menu-container{
    display: flex;
}

.menu{
    margin: 0;
    padding: 0;
    display: grid;
    grid-template-columns: repeat(5,1fr);
    grid-column-gap: 6px;
    margin-bottom: 6px;
    margin-right: 0;
    width: 70%;
}

.menu-item__specify{
    color: red;
}

.menu-item{
    text-align: center;
    list-style: none;
    width: 100%;
    border: 1px black solid;
    padding: 0.4rem 0;
}

.button{
    display: flex;
    margin-bottom: 6px;
    align-items: center;
    <?php
        /*if($_SESSION["permission"]=='e'){
            echo "display: none;";
        }*/
    ?>
}
.button input,
.save-menu input{
    box-shadow: 0px 0px 0px 1px white;
    border-radius: 10px;
    font: inherit;
    cursor: pointer;
    border: none;
    background: center;
    padding: 5px 8px;
    margin: 0 4px;
}

.input-crud input:hover,
.button input:hover,
.save-menu input:hover{
    background: lightyellow;
}

.backdrop{
    display: none;
    z-index: 1;
    position: fixed;
    height: 100vh;
    width: 100vw;
    background: rgba(0,0,0,0.5);
}
.save-menu{
    background: rgb(255, 229, 229);
    z-index: -1;
    opacity:0;
    transform: translateY(-3rem);
    transition: opacity 0.2s,transform 0.5s;
    display: grid;
    justify-items: center;
    grid-row-gap: 1rem;
    position: fixed;
    width: 30vw;
    height: 30vh;
    left: 30%;
    top: 15%;
    padding: 5rem;
    font-size: x-large;
}

.save-menu input{
    font-size: x-large;
}

.save{
    z-index: 2;
    display: grid;
    opacity: 1;
    transform: translateY(0);
}