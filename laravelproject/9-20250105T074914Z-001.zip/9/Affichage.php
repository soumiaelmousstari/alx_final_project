<?php
    require("Etudiant.php");
    require("connexion.php");
    session_start();
    if(!isset($_SESSION["permission"])){
        header("location:index.php");
    }
?>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="Affichage_css.php">
    </head>
    <body>
        <div class="backdrop"></div>
        <div class='save-menu'>
            <section>sauvegarder avec de quitter</section>
            <section>
                <a href='Quiter.php?save=yes'><input type='button' value='oui'></a>
                <a href='Quiter.php?save=no'><input type='button' value='non'></a>
            </section>
        </div>
        <a href=""></a>
        <?php
            if($_SESSION["permission"]=='Administrateur'){
                echo'
                    <div class="creation">
                        <a href="creation.php"><button>Utilisateurs</button></a>
                    </div>
                ';
            }
        ?>
        <form class="form" action="Nouveau.php" method="post">
            <?php
                if($_SESSION["permission"]!='Etudiant'){
                    echo'
                        <div class="input-crud">
                            <input type="submit" name="Nouveau" value="Nouveau">
                            <a href="index.php"><input type="button" value="Quitter"></a>
                        </div>
                        <div class="creation">
                            <a href="Historique.php" class="hi">Historique</a>
                        </div>
                    ';
                }
                else{
                    echo'
                        <div class="input-crud">
                            <a href="index.php"><input type="button" value="Quitter"></a>
                        </div>
                    ';
                }
            ?>
           <ul class="menu menu-item__specify">
                        <li class="menu-item">Nom</li>
                        <li class="menu-item">Maths</li>
                        <li class="menu-item">Informatique</li>
                        <li class="menu-item">Moyenne</li>
                        <li class="menu-item">Mention</li>
            </ul>
            <?php
                ob_start();
                $etudiants=connextion::single();
                $resultas=$etudiants->getconnextion()->query("select * from etudiant");
                while($etudiant=$resultas->fetch()){
                    if($etudiant["valide"]==1){
                        $id=$etudiant["id"];
                        $nom=$etudiant["nom"];
                        $math=$etudiant["math"];
                        $info=$etudiant["info"];
                        $moyenne=($math+$info)/2;
                        $mention;
                        if($moyenne>=10 and $moyenne<12){
                            $mention="Passable";
                        }
                        elseif($moyenne>=12 and $moyenne<14){
                            $mention="A Bien";
                        }
                        elseif($moyenne>=14 and $moyenne<16){
                            $mention="Bien";
                        }
                        elseif($moyenne>=16 and $moyenne<=20){
                            $mention="Tres Bien";
                        }
                        else{
                            $mention="Non Admit";
                        }
                        if($_SESSION["permission"]=='Etudiant'){
                            echo "
                                <div class='menu-container'>
                                    <ul class='menu'>
                                    <li class='menu-item'>$nom</li>
                                    <li class='menu-item'>$math</li>
                                    <li class='menu-item'>$info</li>
                                    <li class='menu-item'>$moyenne</li>
                                    <li class='menu-item'>$mention</li>
                                </ul>
                                </div>
                            ";
                        }
                        if($_SESSION["permission"]!='Etudiant'){
                            echo"
                                <div class='menu-container'>
                                    <ul class='menu'>
                                        <li class='menu-item'>$nom</li>
                                        <li class='menu-item'>$math</li>
                                        <li class='menu-item'>$info</li>
                                        <li class='menu-item'>$moyenne</li>
                                        <li class='menu-item'>$mention</li>
                                    </ul>
                                    <div class='button'>
                                        <a href='Nouveau.php?id_to_modify=$id'><input type='button' value='M'></a>
                                        <a href='Affichage.php?id_to_sup=$id'><input type='button' value='S'></a>
                                        <a href='Bulletin.php?bulletin_id=$id'><input type='button' value='I'></a>
                                    </div>
                                </div>
                            ";
                        }
                    }
                }
                if(isset($_GET["id_to_sup"])){
                    $i=new Etudiant($_GET["id_to_sup"]);
                    $i->DeleteFromBD();
                    header('location:Affichage.php');
                }
                ob_end_flush();
            ?>
        </form>
        <script src="Affichage.js"></script>
    </body>
</html>