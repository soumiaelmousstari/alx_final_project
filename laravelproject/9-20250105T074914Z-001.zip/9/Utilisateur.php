<?php
    class Utilisateur{
        private $Code;
        private $Login;
        private $MotPasse;
        private $Email;
        private $Categorie;
        public function __construct($Code,$Login=null,$MotPasse=null,$Email=null,$Categorie=null){
            $this->Code=$Code;
            $this->Login=$Login;
            $this->MotPasse=$MotPasse;
            $this->Email=$Email;
            $this->Categorie=$Categorie;
        }
        public function AddToBD(){
            $i=connextion::single()->getconnextion();
            $stm=$i->prepare("insert into utilisateur(Login,MotPasse,Email,Categorie) values(:login,:motpasse,:email,:categorie)");
            $t=array('login'=>$this->Login,'motpasse'=>$this->MotPasse,'email'=>$this->Email,'categorie'=>$this->Categorie);
            $stm->execute($t);
            $d=date('d-m-y h:i:s');
            $n=$_SESSION["user_name"];
            $stm=$i->prepare("insert into audit values(:date,:nom,'insert','Utilisateur')");
            $t=array('date'=>$d,'nom'=>$n);
            $stm->execute($t);
        }
        public function SelectFromBD(){
            $i=connextion::single()->getconnextion();
            $query=$i->prepare("select * from utilisateur where Code=?");
            $query->bindParam(1,$this->Code);
            $query->execute();
            return $query->fetch();
        }
        public function UpdateInBD(){
            $i=connextion::single()->getconnextion();
            $stm=$i->prepare("update utilisateur set Login=:login,MotPasse=:motpasse,Email=:email,Categorie=:categorie where Code=:code");
            $t=array('login'=>$this->Login,'motpasse'=>$this->MotPasse,'email'=>$this->Email,'categorie'=>$this->Categorie,'code'=>$this->Code);
            $stm->execute($t);
            $d=date('d-m-y h:i:s');
            $n=$_SESSION["user_name"];
            $stm=$i->prepare("insert into audit values(:date,:nom,'update','Utilisateur')");
            $t=array('date'=>$d,'nom'=>$n);
            $stm->execute($t);
        }
        public function DeleteFromBD(){
            $i=connextion::single()->getconnextion();
            $i->exec("update utilisateur set valide=0 where Code=".$this->Code);
            $d=date('d-m-y h:i:s');
            $n=$_SESSION["user_name"];
            $stm=$i->prepare("insert into audit values(:date,:nom,'delete','Utilisateur')");
            $t=array('date'=>$d,'nom'=>$n);
            $stm->execute($t);
        }
    }
?>