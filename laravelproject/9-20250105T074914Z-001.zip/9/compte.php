<?php
    require("connexion.php");
    require("Utilisateur.php");
    session_start();
    if(!isset($_SESSION["permission"])){
        header("location:index.php");
    }
    $i=connextion::single()->getconnextion();
    $user=new Utilisateur($_SESSION["user_id"]);
    $results=$user->SelectFromBD();
    $login=$results["Login"];
    $motpasse=$results["MotPasse"];
    $email=$results["Email"];
?>
<html>
    <head>
        <link rel="stylesheet" href="compte.css">
    </head>
    <body>
            <ul class="menu-item__specify">
                <li class="menu-item">Login</li>
                <li class="menu-item">:</li>
                <li class="menu-item">
                    <?php
                        if(isset($_GET["modify"]) and $_GET["modify"]==1){
                            echo"<input name='login' type='text' value=$login>";
                        }
                        else echo $login;
                     ?>
                </li>
                <li class="menu-item">
                    <?php
                        if(isset($_GET["modify"]) and $_GET["modify"]==1){
                            echo '<a class="lien valider" href="compte.php?valider=1"><button>Valider</button></a>';
                        }
                        else echo'<a class="lien" href="compte.php?modify=1"><button>Modifier</button></a>';
                    ?>
                </li>
                <li class="menu-item">MotPasse</li>
                <li class="menu-item">:</li>
                <li class="menu-item">
                    <?php
                        if(isset($_GET["modify"]) and $_GET["modify"]==2){
                            echo"<input name='motpasse' type='text' value=$motpasse>";
                        }
                        else echo $motpasse;
                    ?>
                </li>
                <li class="menu-item">
                    <?php
                        if(isset($_GET["modify"]) and $_GET["modify"]==2){
                            echo '<a class="lien valider" href="compte.php?valider=2"><button>Valider</button></a>';
                        }
                        else echo '<a class="lien" href="compte.php?modify=2"><button>Modifier</button></a>';
                    ?>
                </li>
                <li class="menu-item">Email</li>
                <li class="menu-item">:</li>
                <li class="menu-item">
                    <?php
                        if(isset($_GET["modify"]) and $_GET["modify"]==3){
                            echo"<input name='email' type='text' value=$email>";
                        }
                        else echo $email;
                    ?>
                </li>
                <li class="menu-item">
                <?php
                    if(isset($_GET["modify"]) and $_GET["modify"]==3){
                        echo '<a class="lien valider" href="compte.php?valider=3"><button>Valider</button></a>';
                    }
                    else echo'<a class="lien" href="compte.php?modify=3"><button>Modifier</button></a>';
                ?>
                </li>
            </ul>
            <a href="creation.php"><button class="quitter">Quiter</button></a>
        <script src="compte.js"></script>
    </body>
    <?php
        if(isset($_GET["valider"])){
            if($_GET["valider"]==1){
                $i=connextion::single()->getconnextion();
                $i->prepare("update Utilisateur set Login=? where Code=?")->execute(array($_COOKIE["v"],$_SESSION["user_id"]));
                header("location:compte.php");
            }
            if($_GET["valider"]==2){
                $i=connextion::single()->getconnextion();
                $i->prepare("update Utilisateur set MotPasse=? where Code=?")->execute(array($_COOKIE["v"],$_SESSION["user_id"]));
                header("location:compte.php");
            }
            if($_GET["valider"]==3){
                $i=connextion::single()->getconnextion();
                $i->prepare("update Utilisateur set Email=? where Code=?")->execute(array($_COOKIE["v"],$_SESSION["user_id"]));
                header("location:compte.php");
            }
        }
    ?>
</html>