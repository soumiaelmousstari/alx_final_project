<?php
class connextion{
    private static $instancier=null;
    public static function single(){
        if(self::$instancier==null){
            self::$instancier=new connextion();
            return self::$instancier;
        }
        else return self::$instancier;
    }
    public function getconnextion(){
        return new PDO("mysql:host=localhost;dbname=a9","root","");
    }
    public function __destruct(){
        self::$instancier=null;
    }
}
?>