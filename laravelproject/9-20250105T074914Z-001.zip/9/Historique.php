<?php
    require("Etudiant.php");
    require("connexion.php");
    session_start();
    if(!isset($_SESSION["permission"])){
        header("location:index.php");
    }
    if(isset($_GET["clear"])){
        $i=connextion::single()->getconnextion();
        if($_SESSION["permission"]=='Administrateur'){
            $i->exec("delete from audit");
        }
        else{
            $n=$_SESSION["user_name"];
            $i->prepare("delete from audit where Utilisateur=?")->execute(array($n));
        }
        header("location:Historique.php");
    }
?>
<html>
    <head>
        <link rel="stylesheet" href="Affichage_css.php">
        <link rel="stylesheet" href="historique.css">
    </head>
    <body>
        <div class="form">
            <div class="input-crud">
                <a href="Affichage.php"><input type="button" value="Quitter"></a>
                <a href="Historique.php?clear"><input type="button" value="Suprimer Tous"></a>
            </div>
                <ul class="menu menu-item__specify">
                    <li class="menu-item">Date </li>
                    <li class="menu-item">Utilisateur</li>
                    <li class="menu-item">Operation</li>
                    <li class="menu-item">Table</li>
                </ul>
            <?php
                $historiques=connextion::single();
                $resultas=$historiques->getconnextion()->query("select * from audit");
                while($historique=$resultas->fetch()){
                    $date=$historique["Date"];
                    $user=$historique["Utilisateur"];
                    $operation=$historique["Operation"];
                    $table=$historique["Table_nom"];
                    if($_SESSION["permission"]=='Administrateur'){
                        echo "
                            <div class='menu-container'>
                                <ul class='menu'>
                                    <li class='menu-item'>$date</li>
                                    <li class='menu-item'>$user</li>
                                    <li class='menu-item'>$operation</li>
                                    <li class='menu-item'>$table</li>
                                </ul>
                            </div>
                        ";
                    }
                    else{
                        if($historique["Utilisateur"]==$_SESSION["user_name"]){
                            echo "
                                <div class='menu-container'>
                                    <ul class='menu'>
                                        <li class='menu-item'>$date</li>
                                        <li class='menu-item'>$user</li>
                                        <li class='menu-item'>$operation</li>
                                        <li class='menu-item'>$table</li>
                                    </ul>
                                </div>
                            ";
                        }
                    }
                }
            ?>
        </div>
    </body>
</html>