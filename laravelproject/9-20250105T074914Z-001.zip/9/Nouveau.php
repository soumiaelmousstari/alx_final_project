<?php
    require("Etudiant.php");
    require("connexion.php");
    session_start();
    if(!isset($_SESSION["permission"])){
        header("location:index.php");
    }
?>
<html>
    <head>
        <link rel="stylesheet" href="Nouveau.css">
    </head>
    <body>
        <form class="add" action="" method="post">
                <?php
                    $in_nom="";
                    $in_math="";
                    $in_info="";
                    if(isset($_GET["id_to_modify"])){
                        $i=new Etudiant($_GET["id_to_modify"]);
                        $r=$i->SelectFromBD();
                        $in_nom=$r["nom"];
                        $in_math=$r["math"];
                        $in_info=$r["info"];
                    }
                    echo"
                    
                        Nom de l'Etudiant
                        <input type='text' name='nom_etu' value='$in_nom' required>
                
                        Note Maths
                        <input type='text' name='note_math' value='$in_math' required>
                    
                        Note Informatique
                        <input type='text' name='note_info' value='$in_info' required>
                   
                    ";
                ?>
                <div class="button-container">
                    <input class="button" type="submit" value="Valider">
                    <a class="href" href="Affichage.php"><input class="button" type="button" value="Annuler"></a>
                </div>
                
        </form>
        <?php
            if(isset($_POST["nom_etu"]) and isset($_POST["note_math"]) and isset($_POST["note_info"])){
                if(isset($_GET["id_to_modify"])){
                    $i=new Etudiant($_GET["id_to_modify"],$_POST["nom_etu"],$_POST["note_math"],$_POST["note_info"]);
                    $i->UpdateInBD();
                }
                else{
                    $i=new Etudiant(0,$_POST["nom_etu"],$_POST["note_math"],$_POST["note_info"]);
                    $i->AddToBD();
                }
                header("location:Affichage.php");
            }  
        ?>
    </body>
</html>