<html>
    <head>
        <link rel="stylesheet" href="index.css">
    </head>
    <body>
        <form class="sign-in" action="index.php" method="post">
            <h2>Identifiant</h2>
            <input class="inputs" type="text" name="ID" required>
            <h2>Mot de Passe</h2>
            <input class="inputs" type="password" name="pass" required>
            <input classe="valider" type="submit" value="Valider" name="Valider">
        </form>
        <?php
            session_start();
            if(isset($_POST["ID"]) and isset($_POST["pass"])){
                try{
                    $login=new PDO("mysql:host=localhost;dbname=a6","root","");
                    $checkin=$login->query("select * from utilisateur");
                    $not_existe="true";
                    while($tab=$checkin->fetch()){
                        if($_POST["ID"]==$tab["Login"] and $_POST["pass"]==$tab["MotPasse"]){
                            $not_existe="false";
                            $_SESSION["permission"]=$tab["Categorie"];
                            $_SESSION["user_id"]=$tab["Code"];
                            $_SESSION["user_name"]=$tab["Login"];
                            header("location:Affichage.php");
                        }
                    }
                    if($not_existe=="true") echo "<p>Mot de pass ou l'Identifiant est uncorrecte</p>";
                }
                catch(PDOException $e){
                    echo"erreur lors de connection a la base".$e->getMessage();
                }
            }
        ?>
    </body>
</html>