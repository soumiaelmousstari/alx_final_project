<?php
    class Etudiant{
        private $id;
        private $nom;
        private $math;
        private $info;
        public function __construct($id,$nom=null,$math=null,$info=null){
            $this->id=$id;
            $this->nom=$nom;
            $this->math=$math;
            $this->info=$info;
        }
        public function AddToBD(){
            $i=connextion::single()->getconnextion();
            $stm=$i->prepare("insert into etudiant(nom,math,info) values(:nom,:math,:info)");
            $t=array('nom'=>$this->nom,'math'=>$this->math,'info'=>$this->info);
            $stm->execute($t);
            $d=date('d-m-y h:i:s');
            $n=$_SESSION["user_name"];
            $stm=$i->prepare("insert into audit values(:date,:nom,'insert','Etudiant')");
            $t=array('date'=>$d,'nom'=>$n);
            $stm->execute($t);
        }
        public function SelectFromBD(){
            $i=connextion::single()->getconnextion();
            $query=$i->prepare("select * from etudiant where id=?");
            $query->bindParam(1,$this->id);
            $query->execute();
            return $query->fetch();
        }
        public function UpdateInBD(){
            $i=connextion::single()->getconnextion();
            $stm=$i->prepare("update etudiant set nom=:nom,math=:math,info=:info where id=:id");
            $t=array('nom'=>$this->nom,'math'=>$this->math,'info'=>$this->info,'id'=>$this->id);
            $stm->execute($t);
            $d=date('d-m-y h:i:s');
            $n=$_SESSION["user_name"];
            $stm=$i->prepare("insert into audit values(:date,:nom,'update','Etudiant')");
            $t=array('date'=>$d,'nom'=>$n);
            $stm->execute($t);
        }
        public function DeleteFromBD(){
            $i=connextion::single()->getconnextion();
            $i->exec("update etudiant set valide=0 where id=".$this->id);
            $d=date('d-m-y h:i:s');
            $n=$_SESSION["user_name"];
            $stm=$i->prepare("insert into audit values(:date,:nom,'delete','Etudiant')");
            $t=array('date'=>$d,'nom'=>$n);
            $stm->execute($t);
        }
    }
?>